package com.aiteamhub;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class AiBridge {
    private final Context context;
    private final WebView webView;
    private final SecureStore store;
    private final ExecutorService executor = Executors.newFixedThreadPool(4);

    AiBridge(Context context, WebView webView, SecureStore store) {
        this.context = context.getApplicationContext(); this.webView = webView; this.store = store;
    }

    @JavascriptInterface public boolean saveApiKey(String id, String value) {
        try { store.put(id, value); return true; } catch (Exception e) { return false; }
    }
    @JavascriptInterface public String readApiKey(String id) {
        try { return store.get(id); } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public boolean hasApiKey(String id) { return store.has(id); }
    @JavascriptInterface public void deleteApiKey(String id) { store.remove(id); }
    @JavascriptInterface public boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= 23) {
                android.net.Network n = cm.getActiveNetwork();
                NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
                return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            }
            return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
        } catch (Exception e) { return false; }
    }
    @JavascriptInterface public String appVersion() { return "0.1.0"; }

    @JavascriptInterface public void callAi(String requestId, String provider, String keyId, String model, String prompt) {
        executor.execute(() -> {
            String result = "", error = "";
            try {
                String apiKey = store.get(keyId);
                if (apiKey == null || apiKey.isEmpty()) throw new Exception("API key is missing. Save the key first.");
                result = request(provider, apiKey, model, prompt);
            } catch (Exception e) { error = e.getMessage() == null ? "Request failed" : e.getMessage(); }
            final String r = result, er = error;
            webView.post(() -> webView.evaluateJavascript("window.onNativeAiResult(" + JSONObject.quote(requestId) + "," + JSONObject.quote(r) + "," + JSONObject.quote(er) + ")", null));
        });
    }

    private String request(String provider, String key, String model, String prompt) throws Exception {
        String endpoint;
        JSONObject body = new JSONObject();
        if ("openai".equals(provider)) {
            endpoint = "https://api.openai.com/v1/chat/completions";
            body.put("model", model); body.put("messages", new JSONArray().put(new JSONObject().put("role", "user").put("content", prompt)));
        } else if ("claude".equals(provider)) {
            endpoint = "https://api.anthropic.com/v1/messages";
            body.put("model", model); body.put("max_tokens", 3000);
            body.put("messages", new JSONArray().put(new JSONObject().put("role", "user").put("content", prompt)));
        } else if ("gemini".equals(provider)) {
            endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + URLEncoder.encode(key, "UTF-8");
            body.put("contents", new JSONArray().put(new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", prompt)))));
        } else throw new Exception("Unsupported provider: " + provider);

        HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000);
        c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
        if ("openai".equals(provider)) c.setRequestProperty("Authorization", "Bearer " + key);
        if ("claude".equals(provider)) {
            c.setRequestProperty("x-api-key", key);
            c.setRequestProperty("anthropic-version", "2023-06-01");
        }
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
        int status = c.getResponseCode();
        InputStream is = status >= 200 && status < 300 ? c.getInputStream() : c.getErrorStream();
        String raw = readAll(is);
        JSONObject json = new JSONObject(raw);
        if (status < 200 || status >= 300) {
            JSONObject err = json.optJSONObject("error");
            String message = err == null ? json.optString("message", raw) : err.optString("message", raw);
            throw new Exception("HTTP " + status + ": " + message);
        }
        if ("openai".equals(provider)) return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
        if ("claude".equals(provider)) return json.getJSONArray("content").getJSONObject(0).getString("text");
        return json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        try (InputStream input = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int n;
            while ((n = input.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toString("UTF-8");
        }
    }
}
